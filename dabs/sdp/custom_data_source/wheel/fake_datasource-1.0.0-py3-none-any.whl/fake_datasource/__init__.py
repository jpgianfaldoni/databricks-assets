"""
Fake DataSource Package

A custom PySpark DataSource implementation for generating fake data
using the Faker library. Supports both batch and streaming reads.
"""

from fake_datasource.datasource import (
    FakeDataSource,
    FakeDataSourceReader,
    FakeSimpleStreamReader,
)

__version__ = "1.0.0"
__all__ = ["FakeDataSource", "FakeDataSourceReader", "FakeSimpleStreamReader"]

